function update() {
    document.getElementById('text').value = memecount;
    document.title = memecount + "Memes";
    document.getElementById('ammountAutoClick').innerHTML = "Nº de caras legais: " + autoClick;
    document.getElementById('costAutoClick').innerHTML = ((autoClick + 1) * 12) + " Memecoins";
    document.getElementById('ammountPokerFace').innerHTML = "Nº de caras legais: " + pokerFaces;
    document.getElementById('costPokerFace').innerHTML = ((pokerFaces + 1) * 15) + " Memecoins";
    document.getElementById('ammountForeverAlone').innerHTML = "Nº de caras legais: " + foreverAlone;
    document.getElementById('costForeverAlone').innerHTML = ((foreverAlone + 1) * 25) + " Memecoins";
        
    document.getElementById('costMultiplier').innerHTML = ((multiplier + 1) * 100) + " Memecoins";
    document.getElementById('ammountMultiplier').innerHTML = multiplier;
    document.getElementById('costMultiplierhand').innerHTML = ((multiplierHand + 1) * 15) + " Memecoins";
    document.getElementById('ammoutMultiplierhand').innerHTML = multiplierHand;
    document.getElementById('ammountChallengeAccepted').innerHTML = "Nº de caras legais: " + challengeAccepted;
    document.getElementById('costChallengeAccepted').innerHTML = ((challengeAccepted + 1) * 40) + " Memecoins";
    document.getElementById('ammountlol').innerHTML = "Nº de caras legais: " + lol;
    document.getElementById('costlol').innerHTML = ((lol + 1) * 70) + " Memecoins";
    document.getElementById('ammountfuckYeah').innerHTML = "Nº de caras legais: " + fuckYeah;
    document.getElementById('costfuckYeah').innerHTML = ((fuckYeah + 1) * 100) + " Memecoins";
    document.getElementById('ammountMegaClick').innerHTML = megaClick;
    document.getElementById('costMegaClick').innerHTML = ((multiplier + 1) * 15) + " Memecoins";

    


        //manda Freezer=0;
}
var memecount = 1000;
var autoClick = 0;
var pokerFaces = 0;
var multiplier = 1;
var foreverAlone = 0;
var challengeAccepted = 0;
var lol = 0;
var fuckYeah = 0;
var multiplierHand = 1;
var megaClick = 0;
var webSocket = new WebSocket("ws://localhost:8080/Clicker/WebSocketEndPoint"); 

var memecoinSecond = pokerFaces;
        
webSocket.onopen = function(message){ processOpen(message);};
webSocket.onclose = function (message) { processClose(message); };
webSocket.onmessage = function(message){processMessage(message)};
webSocket.onerror = function (message) { processError(message);}
/*
function processOpen(message){
    webSocket.send("server conectado taok");
}
function processClose(message){
    webSocket.send("descontectado");
}
 */



function timer() {
    memecount = memecount + autoClick * multiplier;
    memecount = memecount + pokerFaces * 2 * multiplier;
    memecount = memecount + foreverAlone * 2.5 * multiplier;
    memecount = memecount + challengeAccepted * 5 * multiplier;
    memecount = memecount + lol * 7.5 * multiplier;
    memecount = memecount + fuckYeah * 10 * multiplier;
    webSocket.send(memecount);
    update();
    imgs();
    
}



setInterval(timer, 1000)
function imgs() {
    
      if(multiplier===2){
        $("#img_mult4").hide();
        $("#img_mult3").hide();
        $("#img_mult2").show();
    }else if(multiplier===3){
         $("#img_mult4").hide();
        $("#img_mult3").show();
        $("#img_mult2").hide();
        
    }else if(multiplier>=4){
        $("#img_mult4").show();
        $("#img_mult3").hide();
        $("#img_mult2").hide();
    }else{
        $("#img_mult4").hide();
        $("#img_mult3").hide();
        $("#img_mult2").hide();
    }    
    if(megaClick===0){
         $("#img_dez").hide();
    }else{
         $("#img_dez").show();
    }
   
    if(multiplierHand>1){
          $("#img_double").show();
    }else{
          $("#img_double").hide();
    }
    
}
function add() {
     if(megaClick>0){
        memecount = memecount + 1 * multiplierHand * 10;
        megaClick=megaClick-1;
        
        update();
        }else{
    memecount = memecount + 1 * multiplierHand;
    update();
        }
      webSocket.send(memecount);
      
        
}

function save() {
    localStorage.setItem("memecount", memecount);
    localStorage.setItem("autoClick", autoClick);
    localStorage.setItem("pokerFaces", pokerFaces);
    localStorage.setItem("challengeAccepted", challengeAccepted);
    localStorage.setItem("foreverAlone", foreverAlone);
    localStorage.setItem("lol", lol);
    localStorage.setItem("fuckYeah", fuckYeah);
}

function load() {
    memecount = localStorage.getItem("memecount");
    memecount = parseInt(memecount);
    document.getElementById('text').value = memecount;
    document.title = memecount + "Memes";
    autoClick = localStorage.getItem("autoClick");
    autoClick = parseInt(autoClick);
    pokerFaces = localStorage.getItem("pokerFaces");
    pokerFaces = parseInt(pokerFaces);
    challengeAccepted = localStorage.getItem("challengeAccepted");
    challengeAccepted = parseInt(challengeAccepted);
    foreverAlone = localStorage.getItem("foreverAlone");
    foreverAlone = parseInt(foreverAlone);
    lol = localStorage.getItem("lol");
    lol = parseInt(lol);
    fuckYeah = localStorage.getItem("fuckYeah");
    fuckYeah = parseInt(fuckYeah);
    update()
}

function buyOkay() {
    if (memecount >= ((autoClick + 1) * 12)) {
        memecount = memecount - ((autoClick + 1) * 12);
        autoClick = autoClick + 1;
        update();
    }
}

function buyPokerFace() {
    if (memecount >= ((pokerFaces + 1) * 15)) {
        memecount = memecount - ((pokerFaces + 1) * 15);
        pokerFaces = pokerFaces + 1;
        update();
    }
}

function buyForeverAlone() {
    if (memecount >= ((foreverAlone + 1) * 25)) {
        memecount = memecount - ((foreverAlone + 1) * 25);
        foreverAlone = foreverAlone + 1;
        update();
    }
}

function buyChallengeAccepted() {
    if (memecount >= ((challengeAccepted + 1) * 40)) {
        memecount = memecount - ((challengeAccepted + 1) * 40);
        challengeAccepted = challengeAccepted + 1;
        update();
    }
}

function buyLol() {
    if (memecount >= ((lol + 1) * 70)) {
        memecount = memecount - ((lol + 1) * 70);
        lol = lol + 1;
        update();
    }
}

function buyFuckYeah() {
    if (memecount >= ((fuckYeah + 1) * 100)) {
        memecount = memecount - ((fuckYeah + 1) * 100);
        fuckYeah = fuckYeah + 1;
        update();
    }
}

function buyMultiplier() {
    if (memecount >= ((multiplier + 1) * 100)) {
        memecount = memecount - ((multiplier + 1) * 100);
        multiplier = multiplier + 1;
        update();
    }  
    
}
 function buymultiplierHand() {
    if (memecount >= ((multiplierHand + 1) * 15)) {
        memecount = memecount - ((multiplierHand + 1) * 15);
        multiplierHand = multiplierHand + 1;
        update();
    }
 }
 function buyMegaClick() {
    if (memecount >= ((multiplier + 1) * 15)) {
        memecount = memecount - ((multiplier + 1) * 15);
        megaClick = megaClick + 10;
        update();
    }
 }
 
