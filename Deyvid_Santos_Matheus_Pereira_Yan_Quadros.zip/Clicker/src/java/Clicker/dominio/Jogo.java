package Clicker.dominio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author 6284000
 */
@Entity
@SequenceGenerator(name = "seq_jogo")
@XmlRootElement
public class Jogo implements Serializable {
    
    private int saldo;
   
    @OneToMany
    private List<Item> inventario ;
    
    @OneToMany
    private List<Update> skils;
   
    private int lvl;
    
    private float MemeCoinsSeconds;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq_jogo")
    private Long ID;
    
   
    @OneToOne(mappedBy = "jogo")
    private Usuario usuario;

    public Jogo() {
    }

    @XmlTransient
    public List<Item> getInventario() {
        return inventario;
    }

    public int getLevel() {
        return lvl;
    }

    public float getMemeCoinsSeconds() {
        return MemeCoinsSeconds;
    }

    public int getSaldo() {
        return saldo;
    }

    @XmlTransient
    public List<Update> getSkils() {
        return skils;
    }

    public void setInventario(List<Item> inventario) {
        this.inventario = inventario;
    }

    public void setLevel(int level) {
        this.lvl = lvl;
    }

    public void setMemeCoinsSeconds(float MemeCoinsSeconds) {
        this.MemeCoinsSeconds = MemeCoinsSeconds;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public void setSkils(List<Update> skils) {
        this.skils = skils;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }
    
    
}
