/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clicker.dominio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 *
 * @author Deyvid
 */
public class ConexaoDataBase {
 
    /*static Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:postgres://localhost/sistema_inspecao", "root", "123");
        return connection;
    */

    static Connection getConnection()  {
   
            Connection con;
        try {
            con = DriverManager.getConnection(
                    "jdbc:postgresql://127.0.0.1:5432/db_clicker", "postgres","postgres");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoDataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

        //System.out.println("Driver ok..");
    
   
            

        
    }
    
    

