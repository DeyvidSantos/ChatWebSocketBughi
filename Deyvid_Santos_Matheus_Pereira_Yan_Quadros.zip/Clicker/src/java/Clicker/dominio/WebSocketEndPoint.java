/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clicker.dominio;



import com.sun.corba.se.impl.protocol.giopmsgheaders.ReplyMessage;
import java.io.IOException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

/**
 *
 * @author Deyvid
 */
@ServerEndpoint ("/WebSocketEndPoint")
public class WebSocketEndPoint {

    public WebSocketEndPoint() {
    }

     //private static Set<Session> peers = Collections.newSetFromMap(new ConcurrentHashMap<Session, Boolean>());
     
     
    @OnOpen
    public void handleOpen() {
        System.out.println("cliente conectado...");
    }

    @OnMessage
    public String handleMessage (String message) throws SQLException {
        String replyMessage = message;
        float saldoCoins = Float.parseFloat(replyMessage);
        memeCoinDB(saldoCoins);
        return replyMessage;
    }
    
    
    
    
    public float memeCoinDB(float saldoCoins) throws SQLException{
       
        Jogo jogoCoins = new Jogo();
        
        jogoCoins.setSaldo((int) saldoCoins);
 
        System.out.println("total de coins: "+jogoCoins.getSaldo());
        System.out.println("coins por segundo: " + jogoCoins.getMemeCoinsSeconds());
       
        try (Connection connection = ConexaoDataBase.getConnection()) {
                    String sql = "insert into jogo (saldo,memecoinsseconds) values(?,?)";
                    try(PreparedStatement statement = connection.prepareStatement(sql)) {
                        
                       
                        statement.setInt(1,jogoCoins.getSaldo());
                        statement.setFloat(2,jogoCoins.getMemeCoinsSeconds());
                        statement.execute();
                    }
                    
                }
                  
        
        return saldoCoins;
    
    
    
    
} 
    
    
    
    @OnClose
    public void handleClose() throws SQLException {
        System.out.println("Cliente Desconectado");
         try (Connection connection = ConexaoDataBase.getConnection()) {
                    String sql = "delete from jogo";
           try(PreparedStatement statement = connection.prepareStatement(sql)) {
                        statement.execute();
                    }
                    
         }
    }    
    
    @OnError
    public void hadleError(Throwable t){
    }
}
