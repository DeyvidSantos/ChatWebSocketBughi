package Clicker.dominio;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 6284000
 */
@Entity
@SequenceGenerator(name = "seq_loja")
@XmlRootElement
public class Loja implements Serializable {
    @OneToMany
    List<Item> itens ;
    @OneToMany
    List<Update> updates;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq_loja")
    private Long ID;
    
    
    public Loja() {
    }

    @XmlTransient
    public List<Update> getUpdates() {
        return updates;
    }

    public void setItens(List<Item> itens) {
        this.itens = itens;
    }

    public void setUpdates(List<Update> updates) {
        this.updates = updates;
    }
    



//Jogo player = new Jogo();
        
   //itens.add("nome Item","descricao z","",multiplcador);
    
    //public int multiplicador(player.getlevel,item.qtd){
       // swtich player.getlevel{
             //   case 1:
              //  return 1.25*item.dps;
              // case 2:
               // return 1.25*item.dps;
   // }
        //return 1.25*item.dps;
    //}

    @XmlTransient
    public List<Item> getItens() {
        return itens;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

}
