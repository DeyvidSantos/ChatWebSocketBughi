package Clicker.dominio;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.XmlRootElement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 6284000
 */
@Entity
@SequenceGenerator(name = "seq_item")
@XmlRootElement
public class Item implements Serializable {
    private String nome;
    private String desc;
    private String preco;
    private int memeCoinsSecond;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_item")
    private Long ID;
    
    public String getNome() {
        return nome;
    }

    public Item() {
    }

    public void setMemeCoinsSecond(int memeCoinsSecond) {
        this.memeCoinsSecond = memeCoinsSecond;
    }

    public int getMemeCoinsSecond() {
        return memeCoinsSecond;
    }

    public Item(String nome, String desc, String preco) {
        this.nome = nome;
        this.desc = desc;
        this.preco = preco;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }
    
}
